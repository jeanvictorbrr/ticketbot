const { model, Schema } = require('mongoose');

const guildConfigSchema = new Schema({
    guildId: { type: String, required: true, unique: true },
    ticketPanelChannelId: { type: String, default: null }, // Onde o painel de tickets fica
    ticketPanelMessageId: { type: String, default: null }, // ID da mensagem do painel, para atualização
    ticketCategoryId: { type: String, default: null },
    staffRoleId: { type: String, default: null },
    logChannelId: { type: String, default: null },
    ticketCount: { type: Number, default: 0 },
    // Mensagem que vai DENTRO do canal do ticket
    welcomeMessage: { type: String, default: 'Bem-vindo ao seu ticket! Descreva seu problema e um membro da equipe irá atendê-lo em breve.' },
    // Novas configurações para a embed de ABERTURA de ticket
    ticketPanelTitle: { type: String, default: 'Central de Atendimento' },
    ticketPanelDescription: { type: String, default: 'Clique no botão abaixo para abrir um ticket e receber suporte.' },
    ticketPanelImage: { type: String, default: null }, // URL
    ticketPanelThumbnail: { type: String, default: null }, // URL
});

module.exports = model('GuildConfig', guildConfigSchema);