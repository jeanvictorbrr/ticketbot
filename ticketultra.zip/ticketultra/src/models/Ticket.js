const { model, Schema } = require('mongoose');

const ticketSchema = new Schema({
    guildId: { type: String, required: true },
    ticketId: { type: String, required: true },
    channelId: { type: String, required: true, unique: true },
    ownerId: { type: String, required: true },
    claimedBy: { type: String, default: null },
    status: { type: String, enum: ['aberto', 'atendimento', 'fechado'], default: 'aberto' },
    locked: { type: Boolean, default: false },
    closedBy: { type: String },
    closedAt: { type: Date },
    transcript: { type: String },
    rating: { type: Number, min: 1, max: 5, default: null }, // NOVO: Armazena a avaliação de 1 a 5
}, { timestamps: true });

module.exports = model('Ticket', ticketSchema);