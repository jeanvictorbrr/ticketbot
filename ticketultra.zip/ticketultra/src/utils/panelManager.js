const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, RoleSelectMenuBuilder, ChannelSelectMenuBuilder, ChannelType, StringSelectMenuBuilder } = require('discord.js');
const GuildConfig = require('../models/GuildConfig');
const Ticket = require('../models/Ticket');

// Função helper para mostrar o estado da configuração (atual vs. pendente)
const displayValue = (currentValue, pendingValue, formatFn = (val) => val) => {
    const formattedCurrent = currentValue ? formatFn(currentValue) : 'Não definido';
    if (pendingValue !== undefined && pendingValue !== currentValue) {
        const formattedPending = pendingValue ? formatFn(pendingValue) : 'Não definido';
        return `${formattedCurrent} ➡️ **${formattedPending}**`;
    }
    return formattedCurrent;
};

async function createMainAdminPanel(guildId) {
    const embed = new EmbedBuilder()
        .setTitle('Painel de Administração Principal')
        .setDescription('Use os botões para navegar entre as seções de configuração.')
        .setColor('#FEE75C')
        .addFields(
            { name: '⚙️ Geral', value: 'Defina canais, cargos e categorias.' },
            { name: '🎨 Personalização', value: 'Customize as mensagens e aparência.' },
            { name: '📊 Gerenciador', value: 'Gerencie tickets arquivados.' }
        );

    const components = [
        new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('admin_panel_geral').setLabel('Geral').setStyle(ButtonStyle.Primary).setEmoji('⚙️'),
            new ButtonBuilder().setCustomId('admin_panel_personalizacao').setLabel('Personalização').setStyle(ButtonStyle.Primary).setEmoji('🎨'),
            new ButtonBuilder().setCustomId('admin_panel_manager').setLabel('Gerenciador').setStyle(ButtonStyle.Secondary).setEmoji('📊')
        )
    ];
    return { embeds: [embed], components };
}

async function createGeralAdminPanel(guildId, pendingChanges = {}) {
    const config = await GuildConfig.findOne({ guildId }) || new GuildConfig({ guildId });
    
    const embed = new EmbedBuilder()
        .setTitle('⚙️ Configurações Gerais')
        .setDescription('Altere as opções nos menus. As mudanças ficam pendentes até você clicar em "Salvar".')
        .setColor('#5865F2')
        .addFields(
            { name: 'Canal do Painel de Tickets', value: displayValue(config.ticketPanelChannelId, pendingChanges.ticketPanelChannelId, val => `<#${val}>`) },
            { name: 'Cargo de Staff', value: displayValue(config.staffRoleId, pendingChanges.staffRoleId, val => `<@&${val}>`) },
            { name: 'Categoria de Tickets', value: displayValue(config.ticketCategoryId, pendingChanges.ticketCategoryId, val => `<#${val}>`) },
            { name: 'Canal de Logs', value: displayValue(config.logChannelId, pendingChanges.logChannelId, val => `<#${val}>`) }
        );

    const components = [
        new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('config_panel_channel_menu').setPlaceholder('Alterar Canal do Painel...').addChannelTypes(ChannelType.GuildText)),
        new ActionRowBuilder().addComponents(new RoleSelectMenuBuilder().setCustomId('config_staff_role_menu').setPlaceholder('Alterar Cargo de Staff...')),
        new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('config_ticket_category_menu').setPlaceholder('Alterar Categoria dos Tickets...').addChannelTypes(ChannelType.GuildCategory)),
        new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('config_log_channel_menu').setPlaceholder('Alterar Canal de Logs...').addChannelTypes(ChannelType.GuildText)),
    ];
    
    if (Object.keys(pendingChanges).length > 0) {
        components.push(new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('admin_save_changes').setLabel('Salvar Alterações').setStyle(ButtonStyle.Success).setEmoji('💾'),
            new ButtonBuilder().setCustomId('admin_cancel_changes').setLabel('Cancelar').setStyle(ButtonStyle.Secondary)
        ));
    }

    components.push(new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('admin_panel_main').setLabel('Voltar').setStyle(ButtonStyle.Danger).setEmoji('⬅️')));
    return { embeds: [embed], components };
}

async function createPersonalizacaoAdminPanel(guildId, pendingChanges = {}) {
    const config = await GuildConfig.findOne({ guildId }) || new GuildConfig({ guildId });
    
    const embed = new EmbedBuilder()
        .setTitle('🎨 Painel de Personalização')
        .setDescription('Clique nos botões para editar os textos e aparência. Após salvar, clique em "Atualizar Painel" para aplicar as mudanças.')
        .setColor('#1ABC9C')
        .addFields(
            { name: 'Título da Embed de Abertura', value: displayValue(config.ticketPanelTitle, pendingChanges.ticketPanelTitle, val => `"${val}"`) },
            { name: 'Descrição da Embed de Abertura', value: displayValue(config.ticketPanelDescription, pendingChanges.ticketPanelDescription, val => `"${val}"`) },
            { name: 'Mensagem de Boas-vindas (Dentro do Ticket)', value: displayValue(config.welcomeMessage, pendingChanges.welcomeMessage, val => `"${val}"`) },
            { name: 'URL da Imagem Principal', value: displayValue(config.ticketPanelImage, pendingChanges.ticketPanelImage, val => val ? `[Link](${val})` : 'Não definido') },
            { name: 'URL da Thumbnail', value: displayValue(config.ticketPanelThumbnail, pendingChanges.ticketPanelThumbnail, val => val ? `[Link](${val})` : 'Não definido') }
        );

    const components = [
        new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('edit_panel_title').setLabel('Título').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('edit_panel_desc').setLabel('Descrição').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('edit_welcome_msg').setLabel('Boas-vindas').setStyle(ButtonStyle.Secondary),
        ),
        new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('edit_panel_image').setLabel('Imagem').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('edit_panel_thumb').setLabel('Thumbnail').setStyle(ButtonStyle.Secondary),
        ),
        new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('admin_update_ticket_panel').setLabel('Atualizar Painel de Tickets').setStyle(ButtonStyle.Success).setEmoji('🔄')
        )
    ];
    
    const actionRow = new ActionRowBuilder();
    if (Object.keys(pendingChanges).length > 0) {
        actionRow.addComponents(
            new ButtonBuilder().setCustomId('admin_save_changes').setLabel('Salvar Alterações').setStyle(ButtonStyle.Success).setEmoji('💾'),
            new ButtonBuilder().setCustomId('admin_cancel_changes').setLabel('Cancelar').setStyle(ButtonStyle.Secondary)
        );
    }
    actionRow.addComponents(new ButtonBuilder().setCustomId('admin_panel_main').setLabel('Voltar').setStyle(ButtonStyle.Danger).setEmoji('⬅️'));

    if(actionRow.components.length > 0) {
        components.push(actionRow);
    }

    return { embeds: [embed], components };
}

async function createManagerAdminPanel(guildId) {
    const openTickets = await Ticket.countDocuments({ guildId, status: { $ne: 'fechado' } });
    const recentClosedTickets = await Ticket.find({ guildId, status: 'fechado' }).sort({ closedAt: -1 }).limit(25);
    
    const ratings = await Ticket.find({ guildId, rating: { $ne: null } }).select('rating');
    const averageRating = ratings.length > 0
        ? (ratings.reduce((acc, curr) => acc + curr.rating, 0) / ratings.length).toFixed(2)
        : 'N/A';

    const embed = new EmbedBuilder()
        .setTitle('📊 Gerenciador de Tickets')
        .setColor('#4F545C')
        .setDescription(recentClosedTickets.length > 0 ? 'Use o menu para selecionar um ticket ou veja as estatísticas.' : 'Nenhum ticket fechado encontrado.')
        .addFields(
            { name: 'Tickets Abertos', value: openTickets.toString(), inline: true },
            { name: 'Tickets Fechados Recentes', value: recentClosedTickets.length.toString(), inline: true },
            { name: 'Avaliação Média Geral', value: `⭐ ${averageRating}`, inline: true }
        );

    const components = [];

    if (recentClosedTickets.length > 0) {
        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('manager_ticket_select')
            .setPlaceholder('Selecione um ticket fechado para ver as opções...')
            .addOptions(
                recentClosedTickets.map(ticket => ({
                    label: ticket.ticketId,
                    description: `Dono: ${ticket.ownerId} | Fechado em: ${ticket.closedAt.toLocaleDateString('pt-BR')}`,
                    value: ticket.ticketId,
                }))
            );
        components.push(new ActionRowBuilder().addComponents(selectMenu));
    }

    const actionRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('manager_search_closed').setLabel('Buscar por ID').setStyle(ButtonStyle.Secondary).setEmoji('🔍'),
        new ButtonBuilder().setCustomId('manager_staff_stats').setLabel('Estatísticas da Equipe').setStyle(ButtonStyle.Primary).setEmoji('📈'),
        new ButtonBuilder().setCustomId('manager_delete_all').setLabel('Apagar Todos').setStyle(ButtonStyle.Danger).setEmoji('🗑️')
    );
    components.push(actionRow);

    components.push(new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('admin_panel_main').setLabel('Voltar').setStyle(ButtonStyle.Primary).setEmoji('⬅️')
    ));

    return { embeds: [embed], components };
}

module.exports = {
    createMainAdminPanel,
    createGeralAdminPanel,
    createPersonalizacaoAdminPanel,
    createManagerAdminPanel,
};