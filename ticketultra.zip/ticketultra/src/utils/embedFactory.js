const { EmbedBuilder } = require('discord.js');

const mainColor = '#5865F2'; // Cor principal da embed (Discord Blurple)

function createEmbed(title, description) {
    return new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor(mainColor)
        .setTimestamp();
}

module.exports = { createEmbed };