const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const GuildConfig = require('../../models/GuildConfig');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('painel-tickets')
        .setDescription('Envia ou atualiza o painel de tickets no canal configurado.')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });

        const config = await GuildConfig.findOne({ guildId: interaction.guild.id });
        if (!config || !config.staffRoleId || !config.ticketCategoryId || !config.ticketPanelChannelId) {
            return interaction.editReply({ content: '❌ **Erro:** Configure o **Canal do Painel**, **Cargo de Staff** e **Categoria de Tickets** primeiro na aba "Geral" do `/painel-admin`.' });
        }

        const panelChannel = await interaction.guild.channels.fetch(config.ticketPanelChannelId).catch(() => null);
        if (!panelChannel) {
            return interaction.editReply({ content: '❌ **Erro:** O canal configurado para o painel não foi encontrado. Por favor, defina um novo canal.' });
        }

        const embed = new EmbedBuilder()
            .setTitle(config.ticketPanelTitle || 'Central de Atendimento')
            .setDescription(config.ticketPanelDescription || 'Clique no botão abaixo para abrir um ticket.')
            .setColor('#4CAF50')
            .setImage(config.ticketPanelImage || null)
            .setThumbnail(config.ticketPanelThumbnail || null)
            .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('open_ticket_button').setLabel('Abrir Ticket').setStyle(ButtonStyle.Success).setEmoji('🎟️')
        );

        // Tenta editar a mensagem existente, se houver um ID salvo. Se não, envia uma nova.
        try {
            if (config.ticketPanelMessageId) {
                const existingMessage = await panelChannel.messages.fetch(config.ticketPanelMessageId);
                await existingMessage.edit({ embeds: [embed], components: [row] });
                return interaction.editReply({ content: `✅ Painel de tickets atualizado com sucesso em ${panelChannel}!` });
            }
        } catch (error) {
            console.log("Mensagem antiga do painel não encontrada. Enviando uma nova.");
        }

        const panelMessage = await panelChannel.send({ embeds: [embed], components: [row] });
        await GuildConfig.updateOne({ guildId: interaction.guild.id }, { ticketPanelMessageId: panelMessage.id });

        await interaction.editReply({ content: `✅ Painel de tickets enviado com sucesso para ${panelChannel}!` });
    },
};