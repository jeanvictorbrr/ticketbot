const { SlashCommandBuilder, PermissionFlagsBits, AttachmentBuilder } = require('discord.js');
const Ticket = require('../../models/Ticket');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('buscar-ticket')
        .setDescription('Busca por um ticket arquivado no banco de dados.')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
        .addStringOption(option => 
            option.setName('id')
                .setDescription('O ID do ticket (ex: ticket-001) ou o ID do usuário que o abriu.')
                .setRequired(true)),
    async execute(interaction) {
        await interaction.deferReply({ ephemeral: true });
        const query = interaction.options.getString('id');

        const ticket = await Ticket.findOne({
            guildId: interaction.guild.id,
            $or: [{ ticketId: query }, { ownerId: query }]
        });

        if (!ticket) {
            return interaction.editReply({ content: 'Nenhum ticket encontrado com esse ID ou por este usuário.' });
        }

        if (!ticket.transcript) {
            return interaction.editReply({ content: 'Este ticket foi encontrado, mas não possui uma transcrição salva.' });
        }

        const attachment = new AttachmentBuilder(Buffer.from(ticket.transcript, 'utf-8'), { name: `transcript-${ticket.ticketId}.html` });

        await interaction.editReply({
            content: `Transcrição encontrada para o ticket \`${ticket.ticketId}\`, aberto por <@${ticket.ownerId}>.`,
            files: [attachment]
        });
    },
};