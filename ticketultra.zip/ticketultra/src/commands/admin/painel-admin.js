const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { createMainAdminPanel } = require('../../utils/panelManager'); 

module.exports = {
    data: new SlashCommandBuilder()
        .setName('painel-admin')
        .setDescription('Abre o painel de configuração do bot de tickets.')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
    async execute(interaction) {
        try {
            const { embeds, components } = await createMainAdminPanel(interaction.guild.id);
            await interaction.reply({ embeds, components, ephemeral: true });
        } catch (error) {
            console.error("Erro ao executar /painel-admin:", error);
            await interaction.reply({ content: "Ocorreu um erro ao gerar o painel de administração.", ephemeral: true });
        }
    },
};