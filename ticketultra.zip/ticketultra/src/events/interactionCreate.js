const { Events, ChannelType, PermissionsBitField, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, RoleSelectMenuBuilder, ChannelSelectMenuBuilder, AttachmentBuilder, StringSelectMenuBuilder, UserSelectMenuBuilder } = require('discord.js');
const discordTranscripts = require('discord-html-transcripts');
const GuildConfig = require('../models/GuildConfig');
const Ticket = require('../models/Ticket');
const { createMainAdminPanel, createGeralAdminPanel, createPersonalizacaoAdminPanel, createManagerAdminPanel } = require('../utils/panelManager');

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
const pendingAdminChanges = new Map();

async function isAllowed(interaction) {
    if (interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return true;
    }
    const config = await GuildConfig.findOne({ guildId: interaction.guild.id });
    if (!config || !config.staffRoleId) {
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ content: 'Ação restrita a Administradores (cargo de staff não configurado).', ephemeral: true });
        }
        return false;
    }
    if (!interaction.member.roles.cache.has(config.staffRoleId)) {
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ content: 'Você não tem o cargo de staff necessário para usar este botão.', ephemeral: true });
        }
        return false;
    }
    return true;
}

async function updateTicketPanel(interactionOrChannel, ticketData) {
    const channel = interactionOrChannel.channel || interactionOrChannel;
    if (!ticketData) {
        ticketData = await Ticket.findOne({ channelId: channel.id });
        if (!ticketData) return;
    }
    const statusMap = { aberto: '🟢 Aberto', atendimento: '🟡 Em Atendimento', fechado: '🔴 Fechado' };
    const panelEmbed = new EmbedBuilder()
        .setColor(ticketData.status === 'atendimento' ? '#E67E22' : '#3498DB')
        .setTitle(`Painel de Controle | Ticket: ${ticketData.ticketId}`)
        .setDescription('Use os botões abaixo para gerenciar o ticket.')
        .addFields(
            { name: 'Status', value: statusMap[ticketData.status], inline: true },
            { name: 'Usuário', value: `<@${ticketData.ownerId}>`, inline: true },
            { name: 'Atendente', value: ticketData.claimedBy ? `<@${ticketData.claimedBy}>` : 'Ninguém', inline: true },
            { name: 'Ticket Trancado', value: ticketData.locked ? 'Sim 🔒' : 'Não 🔓', inline: true }
        ).setTimestamp();
        
    const mainControls = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`ticket_claim_${ticketData.channelId}`).setLabel('Assumir').setStyle(ButtonStyle.Success).setDisabled(!!ticketData.claimedBy),
        new ButtonBuilder().setCustomId(`ticket_lock_${ticketData.channelId}`).setLabel(ticketData.locked ? 'Destrancar' : 'Trancar').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId(`ticket_close_${ticketData.channelId}`).setLabel('Fechar').setStyle(ButtonStyle.Danger)
    );

    const toolControls = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`ticket_user_info_${ticketData.channelId}`).setLabel('Info do Usuário').setStyle(ButtonStyle.Primary).setEmoji('👤'),
        new ButtonBuilder().setCustomId(`ticket_manage_members_${ticketData.channelId}`).setLabel('Gerenciar Membros').setStyle(ButtonStyle.Primary).setEmoji('👥')
    );

    try {
        const messages = await channel.messages.fetch({ limit: 50 });
        const panelMessage = messages.find(m => m.author.id === channel.client.user.id && m.embeds[0]?.title?.includes('Painel de Controle'));
        if (panelMessage) {
            await panelMessage.edit({ embeds: [panelEmbed], components: [mainControls, toolControls] });
        } else {
            await channel.send({ embeds: [panelEmbed], components: [mainControls, toolControls] });
        }
    } catch(err) { console.error("Erro ao editar painel do ticket:", err); }
}

async function handleOpenTicket(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const { guild, member } = interaction;
    try {
        await interaction.editReply({ content: '`[■□□□] Iniciando processo de abertura...`' });
        const config = await GuildConfig.findOne({ guildId: guild.id });
        await sleep(1000);
        await interaction.editReply({ content: '`[■■□□] Validando configurações do servidor...`' });
        if (!config || !config.staffRoleId || !config.ticketCategoryId) {
            return interaction.editReply({ content: '❌ **Erro:** O sistema de tickets não está configurado.' });
        }
        const existingTicket = await Ticket.findOne({ guildId: guild.id, ownerId: member.id, status: { $ne: 'fechado' } });
        if (existingTicket) {
            return interaction.editReply({ content: `❌ **Erro:** Você já tem um ticket aberto em <#${existingTicket.channelId}>.` });
        }
        await sleep(1500);
        await interaction.editReply({ content: '`[■■■□] Alocando canal seguro...`' });
        config.ticketCount += 1;
        await config.save();
        const ticketId = `ticket-${config.ticketCount.toString().padStart(4, '0')}`;
        const channel = await guild.channels.create({
            name: ticketId, type: ChannelType.GuildText, parent: config.ticketCategoryId,
            topic: `Ticket de ${member.user.tag} (ID: ${member.id})`,
            permissionOverwrites: [
                { id: guild.id, deny: [PermissionsBitField.Flags.ViewChannel] },
                { id: member.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] },
                { id: config.staffRoleId, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory, PermissionsBitField.Flags.ManageMessages] },
            ],
        });
        await sleep(1000);
        await interaction.editReply({ content: '`[■■■■] Conectando e registrando...`' });
        const newTicket = new Ticket({ guildId: guild.id, ticketId, channelId: channel.id, ownerId: member.id });
        await newTicket.save();
        const welcomeMessage = config.welcomeMessage || 'Bem-vindo ao seu ticket!';
        await channel.send({ content: `${member}, ${welcomeMessage} <@&${config.staffRoleId}>` });
        await updateTicketPanel(channel, newTicket);
        await sleep(500);
        await interaction.editReply({ content: `✅ **Concluído!** Seu ticket foi aberto em ${channel}!` });
        const dmEmbed = new EmbedBuilder().setColor('#4CAF50').setTitle('✅ Ticket Criado').setDescription(`Seu ticket **${ticketId}** foi criado no servidor **${guild.name}**.`).addFields({ name: 'Acesse seu ticket', value: `${channel}` }).setTimestamp();
        await member.send({ embeds: [dmEmbed] }).catch(() => {
            channel.send({ content: `⚠️ Não consegui te notificar por DM.` });
        });
    } catch (error) {
        console.error("Erro ao abrir ticket:", error);
        await interaction.editReply({ content: '❌ Ocorreu um erro inesperado.' }).catch(() => {});
    }
}

async function handleCloseTicket(interaction, ticket) {
    const { channel, member, guild } = interaction;
    const closingMessage = await interaction.reply({ content: '`Iniciando sequência de fechamento...`', fetchReply: true });
    try {
        const steps = [
            { delay: 2000, text: '`[■□□□] Gerando transcrição em HTML`' },
            { delay: 2000, text: '`[■■□□] Salvando registro no banco de dados`' },
            { delay: 1500, text: '`[■■■□] Enviando logs e notificações`' },
            { delay: 1000, text: '`[■■■■] Limpando e preparando para deletar o canal`' }
        ];
        
        const htmlBuffer = await discordTranscripts.createTranscript(channel, {
            limit: -1, returnType: 'buffer', filename: `transcript-${ticket.ticketId}.html`,
            saveImages: true, poweredBy: false
       });
       const htmlString = htmlBuffer.toString('utf-8');

        for (const step of steps) {
            await sleep(400);
            let baseText = step.text;
            for (let i = 0; i < 3; i++) {
                await closingMessage.edit({ content: `${baseText}${'.'.repeat(i + 1)}` });
                await sleep(400);
            }
            await sleep(step.delay - 1200);
        }
        
        const owner = await guild.members.fetch(ticket.ownerId).catch(() => null);
        if (owner) {
            const attachment = new AttachmentBuilder(htmlBuffer, { name: `transcript-${ticket.ticketId}.html` });
            const dmEmbed = new EmbedBuilder().setColor('#E74C3C').setTitle('Ticket Finalizado').setDescription(`Seu ticket **${ticket.ticketId}** no servidor **${guild.name}** foi fechado.`).addFields({ name: 'Fechado por', value: `${member}` }).setFooter({ text: 'A transcrição da conversa está anexa.' });
            await owner.send({ embeds: [dmEmbed], files: [attachment] }).catch(() => {});
        }

        ticket.status = 'fechado';
        ticket.closedBy = member.id;
        ticket.closedAt = new Date();
        ticket.transcript = htmlString;
        await ticket.save();
        
        const config = await GuildConfig.findOne({ guildId: guild.id });
        if (config?.logChannelId) {
            const logAttachment = new AttachmentBuilder(htmlBuffer, { name: `transcript-${ticket.ticketId}.html` });
            const logChannel = await guild.channels.fetch(config.logChannelId).catch(() => null);
            if (logChannel) {
                const logEmbed = new EmbedBuilder().setTitle('Log de Ticket Fechado').setColor('#E74C3C').addFields({ name: 'Ticket ID', value: ticket.ticketId, inline: true },{ name: 'Aberto por', value: `<@${ticket.ownerId}>` },{ name: 'Fechado por', value: `${member}` });
                await logChannel.send({ embeds: [logEmbed], files: [logAttachment] });
            }
        }
        
        if (owner) {
            try {
                const ratingEmbed = new EmbedBuilder().setColor('#FEE75C').setTitle('Avalie nosso Atendimento!').setDescription('Sua opinião é muito importante. Por favor, selecione uma nota de 1 a 5 estrelas para o suporte que você recebeu.');
                
                const ratingMenu = new StringSelectMenuBuilder()
                    .setCustomId(`ticket_rate_select_${ticket.ticketId}`)
                    .setPlaceholder('Escolha sua avaliação...')
                    .addOptions(
                        { label: '⭐ (1/5) - Péssimo', value: '1' },
                        { label: '⭐⭐ (2/5) - Ruim', value: '2' },
                        { label: '⭐⭐⭐ (3/5) - Bom', value: '3' },
                        { label: '⭐⭐⭐⭐ (4/5) - Ótimo', value: '4' },
                        { label: '⭐⭐⭐⭐⭐ (5/5) - Perfeito!', value: '5' }
                    );
                
                const ratingRow = new ActionRowBuilder().addComponents(ratingMenu);
                await owner.send({ embeds: [ratingEmbed], components: [ratingRow] });
            } catch (error) { console.log("Não foi possível enviar a DM de avaliação."); }
        }

        await closingMessage.edit({ content: '✅ **Ticket Arquivado!** Este canal será deletado em 10 segundos.' });
        setTimeout(() => channel.delete('Ticket Fechado').catch(err => console.error("Erro ao deletar canal:", err)), 10000);
    } catch (error) {
        console.error("Erro na sequência de fechamento:", error);
        await closingMessage.edit({ content: '❌ Ocorreu um erro ao fechar o ticket.' }).catch(()=>{});
    }
}

async function handleButtonInteraction(interaction) {
    const { customId, guild, member } = interaction;

    if (customId === 'open_ticket_button') {
        return handleOpenTicket(interaction);
    }
    
    const modalCustomizationMap = {
        'edit_panel_title': { id: 'modal_panel_title', title: 'Editar Título da Embed', label: 'Novo Título', style: TextInputStyle.Short, dbField: 'ticketPanelTitle' },
        'edit_panel_desc': { id: 'modal_panel_desc', title: 'Editar Descrição da Embed', label: 'Nova Descrição', style: TextInputStyle.Paragraph, dbField: 'ticketPanelDescription' },
        'edit_welcome_msg': { id: 'modal_welcome_msg', title: 'Editar Mensagem de Boas-vindas', label: 'Nova Mensagem (dentro do ticket)', style: TextInputStyle.Paragraph, dbField: 'welcomeMessage' },
        'edit_panel_image': { id: 'modal_panel_image', title: 'Editar Imagem da Embed', label: 'URL da Nova Imagem', style: TextInputStyle.Short, dbField: 'ticketPanelImage' },
        'edit_panel_thumb': { id: 'modal_panel_thumb', title: 'Editar Thumbnail da Embed', label: 'URL da Nova Thumbnail', style: TextInputStyle.Short, dbField: 'ticketPanelThumbnail' },
    };

    if (modalCustomizationMap[customId]) {
        if (!await isAllowed(interaction)) return;
        const config = await GuildConfig.findOne({ guildId: guild.id });
        const data = modalCustomizationMap[customId];
        const modal = new ModalBuilder().setCustomId(data.id).setTitle(data.title);
        const input = new TextInputBuilder().setCustomId(data.id + '_input').setLabel(data.label).setStyle(data.style).setValue(config?.[data.dbField] || '').setRequired(false);
        modal.addComponents(new ActionRowBuilder().addComponents(input));
        return interaction.showModal(modal);
    }
    
    if (customId === 'manager_search_closed' || customId.startsWith('delete_ticket_record_') || customId === 'manager_delete_all') {
        if (!await isAllowed(interaction)) return;
        if (customId === 'manager_search_closed') {
            const modal = new ModalBuilder().setCustomId('search_closed_modal').setTitle('Buscar Ticket Fechado').addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('search_query_input').setLabel('ID do Ticket ou ID do Usuário').setStyle(TextInputStyle.Short).setRequired(true)));
            return interaction.showModal(modal);
        }
        if (customId.startsWith('delete_ticket_record_')) {
            const ticketId = customId.split('_').pop();
            const modal = new ModalBuilder().setCustomId(`confirm_delete_modal_${ticketId}`).setTitle('Confirmar Exclusão').addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('confirm_delete_input').setLabel(`Digite "${ticketId}" para confirmar`).setStyle(TextInputStyle.Short).setRequired(true).setPlaceholder(ticketId)));
            return interaction.showModal(modal);
        }
        if (customId === 'manager_delete_all') {
            const modal = new ModalBuilder().setCustomId('confirm_delete_all_modal').setTitle('APAGAR TODOS OS REGISTROS?').addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('confirm_delete_all_input').setLabel("Digite 'DELETAR TUDO AGORA'").setStyle(TextInputStyle.Short).setRequired(true)));
            return interaction.showModal(modal);
        }
    }

    if (customId.startsWith('manager_download_')) {
        if (!await isAllowed(interaction)) return;
        await interaction.deferReply({ ephemeral: true });
        const ticketId = customId.split('_').pop();
        const ticket = await Ticket.findOne({ guildId: guild.id, ticketId });
        if (!ticket || !ticket.transcript) return interaction.editReply({ content: 'Transcrição não encontrada.' });
        const attachment = new AttachmentBuilder(Buffer.from(ticket.transcript, 'utf-8'), { name: `transcript-${ticket.ticketId}.html` });
        return interaction.editReply({ content: `Transcrição para **${ticketId}**`, files: [attachment] });
    }

    if (customId.startsWith('ticket_user_info_')) {
        if (!await isAllowed(interaction)) return;
        await interaction.deferReply({ ephemeral: true });
        const ticket = await Ticket.findOne({ channelId: interaction.channel.id });
        const owner = await guild.members.fetch(ticket.ownerId).catch(() => null);
        if (!owner) return interaction.editReply('Não foi possível encontrar o membro no servidor.');

        const embed = new EmbedBuilder()
            .setTitle(`👤 Informações de ${owner.user.tag}`)
            .setThumbnail(owner.user.displayAvatarURL())
            .addFields(
                { name: 'Entrou no Servidor', value: `<t:${Math.floor(owner.joinedTimestamp / 1000)}:R>`, inline: true },
                { name: 'Conta Criada', value: `<t:${Math.floor(owner.user.createdTimestamp / 1000)}:R>`, inline: true },
                { name: 'Cargos', value: owner.roles.cache.map(r => r.name).join(', ').substring(0, 1020) || 'Nenhum' }
            );
        return interaction.editReply({ embeds: [embed] });
    }

    if (customId.startsWith('ticket_manage_members_')) {
        if (!await isAllowed(interaction)) return;
        const addMenu = new UserSelectMenuBuilder().setCustomId(`ticket_add_user_${interaction.channelId}`).setPlaceholder('Adicionar um membro ao ticket...');
        const removeMenu = new UserSelectMenuBuilder().setCustomId(`ticket_remove_user_${interaction.channelId}`).setPlaceholder('Remover um membro do ticket...');
        
        return interaction.reply({
            content: 'Use os menus abaixo para gerenciar os membros deste ticket.',
            components: [new ActionRowBuilder().addComponents(addMenu), new ActionRowBuilder().addComponents(removeMenu)],
            ephemeral: true
        });
    }

    if (customId.startsWith('ticket_')) {
        if (!await isAllowed(interaction)) return;
        const channelId = customId.split('_').pop();
        const ticket = await Ticket.findOne({ channelId });
        if (!ticket) return interaction.reply({ content: "Ticket não encontrado.", ephemeral: true });
        const action = customId.split('_')[1];
        switch (action) {
            case 'claim':
                await interaction.deferUpdate();
                if (ticket.claimedBy) return interaction.editReply({ content: 'Ticket já assumido.', ephemeral: true });
                ticket.claimedBy = member.id; ticket.status = 'atendimento';
                await ticket.save();
                await interaction.channel.send({ content: `✅ Ticket assumido por ${member}!` });
                await updateTicketPanel(interaction, ticket);
                break;
            case 'lock':
                await interaction.deferUpdate();
                ticket.locked = !ticket.locked;
                await ticket.save();
                await interaction.channel.permissionOverwrites.edit(ticket.ownerId, { SendMessages: !ticket.locked });
                const lockAction = ticket.locked ? 'trancado 🔒' : 'destrancado 🔓';
                await interaction.channel.send({ content: `Ticket ${lockAction} por ${member}.` });
                await updateTicketPanel(interaction, ticket);
                break;
            case 'close':
                await handleCloseTicket(interaction, ticket);
                break;
        }
        return;
    }
    
    if (!await isAllowed(interaction)) return;
    await interaction.deferUpdate();

    if (customId === 'admin_panel_main') {
        const { embeds, components } = await createMainAdminPanel(guild.id);
        await interaction.editReply({ embeds, components, content: '' });
    } else if (customId === 'admin_panel_geral') {
        const { embeds, components } = await createGeralAdminPanel(guild.id, pendingAdminChanges.get(guild.id));
        await interaction.editReply({ embeds, components, content: '' });
    } else if (customId === 'admin_panel_personalizacao') {
        const { embeds, components } = await createPersonalizacaoAdminPanel(guild.id, pendingAdminChanges.get(guild.id));
        await interaction.editReply({ embeds, components, content: '' });
    } else if (customId === 'admin_panel_manager') {
        const { embeds, components } = await createManagerAdminPanel(guild.id);
        await interaction.editReply({ embeds, components, content: '' });
    } else if (customId === 'manager_staff_stats') {
        const stats = await Ticket.aggregate([ { $match: { guildId: guild.id, claimedBy: { $ne: null } } }, { $group: { _id: '$claimedBy', totalTickets: { $sum: 1 }, averageRating: { $avg: '$rating' } }}, { $sort: { totalTickets: -1 } } ]);
        if (stats.length === 0) return interaction.followUp({ content: 'Ainda não há dados suficientes para gerar estatísticas.', ephemeral: true });
        const embed = new EmbedBuilder().setTitle('📈 Estatísticas da Equipe de Suporte').setColor('#5865F2');
        for (const staff of stats) {
            const member = await guild.members.fetch(staff._id).catch(() => null);
            embed.addFields({ name: member ? member.user.tag : `ID: ${staff._id}`, value: `**Tickets Atendidos:** ${staff.totalTickets}\n**Avaliação Média:** ${staff.averageRating ? `⭐ ${staff.averageRating.toFixed(2)}` : 'N/A'}`, inline: false });
        }
        return interaction.followUp({ embeds: [embed], ephemeral: true });
    } else if (customId === 'admin_save_changes') {
        const changesToSave = pendingAdminChanges.get(guild.id);
        if (!changesToSave || Object.keys(changesToSave).length === 0) return interaction.editReply({ content: 'Não há alterações pendentes.', embeds: [], components: [] });
        await GuildConfig.updateOne({ guildId: guild.id }, { $set: changesToSave }, { upsert: true });
        pendingAdminChanges.delete(guild.id);
        const { embeds, components } = await createMainAdminPanel(guild.id);
        await interaction.editReply({ content: '✅ Alterações salvas com sucesso!', embeds, components });
    } else if (customId === 'admin_cancel_changes') {
        pendingAdminChanges.delete(guild.id);
        const { embeds, components } = await createMainAdminPanel(guild.id);
        await interaction.editReply({ content: 'Alterações pendentes foram canceladas.', embeds, components });
    } else if (customId === 'admin_update_ticket_panel') {
        const config = await GuildConfig.findOne({ guildId: interaction.guild.id });
        if (!config.ticketPanelChannelId || !config.ticketPanelMessageId) return interaction.followUp({ content: '❌ Use `/painel-tickets` primeiro para criar um painel inicial.', ephemeral: true });
        const panelChannel = await interaction.guild.channels.fetch(config.ticketPanelChannelId).catch(() => null);
        if (!panelChannel) return interaction.followUp({ content: '❌ O canal do painel não foi encontrado.', ephemeral: true });
        try {
            const panelMessage = await panelChannel.messages.fetch(config.ticketPanelMessageId);
            const newEmbed = new EmbedBuilder().setTitle(config.ticketPanelTitle).setDescription(config.ticketPanelDescription).setColor('#4CAF50').setImage(config.ticketPanelImage).setThumbnail(config.ticketPanelThumbnail).setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() });
            const newRow = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('open_ticket_button').setLabel('Abrir Ticket').setStyle(ButtonStyle.Success).setEmoji('🎟️'));
            await panelMessage.edit({ embeds: [newEmbed], components: [newRow] });
            await interaction.followUp({ content: `✅ Painel atualizado em ${panelChannel}!`, ephemeral: true });
        } catch (error) {
            console.error(error);
            await interaction.followUp({ content: '❌ Não foi possível editar a mensagem. Use `/painel-tickets` para criar um novo.', ephemeral: true });
        }
    }
}

async function handleSelectMenuInteraction(interaction) {
    const { customId, values, guild } = interaction;
    const value = values[0];

    if (customId.startsWith('ticket_rate_select_')) {
        await interaction.deferUpdate();
        const ticketId = customId.split('_').pop();
        const ratingValue = parseInt(value, 10);

        await Ticket.updateOne({ ticketId }, { $set: { rating: ratingValue } });

        const confirmationEmbed = new EmbedBuilder()
            .setColor('#2ECC71')
            .setTitle('✅ Obrigado pelo seu Feedback!')
            .setDescription(`Você avaliou o atendimento com ${'⭐'.repeat(ratingValue)} (${ratingValue}/5).`);

        const disabledMenu = new StringSelectMenuBuilder()
            .setCustomId(`rated_select_${ticketId}`)
            .setPlaceholder('Avaliação enviada com sucesso!')
            .setDisabled(true)
            .addOptions({ label: 'Obrigado!', value: 'thx' });
            
        return interaction.editReply({ embeds: [confirmationEmbed], components: [new ActionRowBuilder().addComponents(disabledMenu)] });
    }

    if (customId.startsWith('ticket_add_user_') || customId.startsWith('ticket_remove_user_')) {
        if (!await isAllowed(interaction)) return;
        await interaction.deferUpdate();
        const isAdding = customId.startsWith('ticket_add_user_');
        const memberToManage = await guild.members.fetch(value);
        if (isAdding) {
            await interaction.channel.permissionOverwrites.edit(memberToManage.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true });
            await interaction.followUp({ content: `${memberToManage} foi adicionado a este ticket.`, ephemeral: true });
            return interaction.channel.send(`> ${memberToManage} foi adicionado ao ticket por ${interaction.member}.`);
        } else {
            await interaction.channel.permissionOverwrites.delete(memberToManage.id);
            await interaction.followUp({ content: `${memberToManage} foi removido deste ticket.`, ephemeral: true });
            return interaction.channel.send(`> ${memberToManage} foi removido do ticket por ${interaction.member}.`);
        }
    }

    if (customId === 'manager_ticket_select') {
        if (!await isAllowed(interaction)) return;
        await interaction.deferUpdate();
        const ticketId = value;
        const ticket = await Ticket.findOne({ guildId: guild.id, ticketId });
        if (!ticket) return interaction.editReply({ content: 'Ticket não encontrado.', embeds: [], components: [] });
        const tempEmbed = new EmbedBuilder().setTitle(`Gerenciando: ${ticket.ticketId}`).setDescription(`Ações para o ticket de <@${ticket.ownerId}>.`).setColor('#2ECC71');
        const actionRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`manager_download_${ticketId}`).setLabel('Baixar Transcrição').setStyle(ButtonStyle.Success).setEmoji('📄'),
            new ButtonBuilder().setCustomId(`delete_ticket_record_${ticketId}`).setLabel('Apagar Registro').setStyle(ButtonStyle.Danger).setEmoji('🗑️')
        );
        const { embeds, components } = await createManagerAdminPanel(guild.id);
        embeds.push(tempEmbed);
        components.push(actionRow);
        return interaction.editReply({ embeds, components });
    }
    
    if (!await isAllowed(interaction)) return;
    await interaction.deferUpdate();
    let configField = '';
    switch (customId) {
        case 'config_panel_channel_menu': configField = 'ticketPanelChannelId'; break;
        case 'config_staff_role_menu': configField = 'staffRoleId'; break;
        case 'config_ticket_category_menu': configField = 'ticketCategoryId'; break;
        case 'config_log_channel_menu': configField = 'logChannelId'; break;
        default: return;
    }
    
    const currentChanges = pendingAdminChanges.get(guild.id) || {};
    currentChanges[configField] = value;
    pendingAdminChanges.set(guild.id, currentChanges);
    const { embeds, components } = await createGeralAdminPanel(guild.id, currentChanges);
    await interaction.editReply({ embeds, components });
}

async function handleModalSubmitInteraction(interaction) {
    if (!await isAllowed(interaction)) return;
    const { customId, fields, guild } = interaction;
    const modalCustomizationMap = {
        'modal_panel_title': 'ticketPanelTitle', 'modal_panel_desc': 'ticketPanelDescription',
        'modal_welcome_msg': 'welcomeMessage', 'modal_panel_image': 'ticketPanelImage',
        'modal_panel_thumb': 'ticketPanelThumbnail',
    };

    if (modalCustomizationMap[customId]) {
        await interaction.deferUpdate();
        const dbField = modalCustomizationMap[customId];
        const value = fields.getTextInputValue(customId + '_input');
        const currentChanges = pendingAdminChanges.get(guild.id) || {};
        currentChanges[dbField] = value;
        pendingAdminChanges.set(guild.id, currentChanges);
        const { embeds, components } = await createPersonalizacaoAdminPanel(guild.id, currentChanges);
        return interaction.editReply({ embeds, components });
    }

    await interaction.deferReply({ ephemeral: true });
    if (customId === 'search_closed_modal') {
        const query = fields.getTextInputValue('search_query_input');
        const ticket = await Ticket.findOne({ guildId: guild.id, status: 'fechado', $or: [{ ticketId: query }, { ownerId: query }] });
        if (!ticket) return interaction.editReply({ content: 'Nenhum ticket fechado encontrado.' });
        const embed = new EmbedBuilder().setTitle(`Detalhes: ${ticket.ticketId}`).addFields({ name: 'Dono', value: `<@${ticket.ownerId}>`, inline: true }, { name: 'Fechado por', value: `<@${ticket.closedBy}>`, inline: true }, { name: 'Data', value: `<t:${Math.floor(ticket.closedAt.getTime() / 1000)}:f>` });
        const attachment = new AttachmentBuilder(Buffer.from(ticket.transcript, 'utf-8'), { name: `transcript-${ticket.ticketId}.html` });
        const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`delete_ticket_record_${ticket.ticketId}`).setLabel('Apagar').setStyle(ButtonStyle.Danger));
        return interaction.editReply({ embeds: [embed], files: [attachment], components: [row] });
    }

    if (customId.startsWith('confirm_delete_modal_')) {
        const ticketId = customId.split('_').pop();
        const confirmation = fields.getTextInputValue('confirm_delete_input');
        if (confirmation !== ticketId) return interaction.editReply({ content: 'Confirmação incorreta.' });
        await Ticket.deleteOne({ guildId: guild.id, ticketId: ticketId });
        const { embeds, components } = await createManagerAdminPanel(guild.id);
        return interaction.editReply({ content: `✅ Registro \`${ticketId}\` excluído.`, embeds, components });
    }

    if (customId === 'confirm_delete_all_modal') {
        const confirmation = fields.getTextInputValue('confirm_delete_all_input');
        if (confirmation !== 'DELETAR TUDO AGORA') return interaction.editReply({ content: 'Confirmação incorreta.' });
        const result = await Ticket.deleteMany({ guildId: guild.id });
        const { embeds, components } = await createManagerAdminPanel(guild.id);
        await interaction.editReply({ content: `✅ **${result.deletedCount}** registros foram excluídos.`, embeds, components });
    }
}

module.exports = {
    name: Events.InteractionCreate,
    execute: async function(interaction) {
        if (!interaction.inGuild()) return;
        try {
            if (interaction.isChatInputCommand()) {
                const command = interaction.client.commands.get(interaction.commandName);
                if (command) await command.execute(interaction);
            } else if (interaction.isButton()) {
                await handleButtonInteraction(interaction);
            } else if (interaction.isAnySelectMenu()) {
                await handleSelectMenuInteraction(interaction);
            } else if (interaction.isModalSubmit()) {
                await handleModalSubmitInteraction(interaction);
            }
        } catch (error) {
            console.error(`Erro na interação ${interaction.customId || interaction.commandName}:`, error);
            const replyOptions = { content: 'Ocorreu um erro ao processar esta ação.', ephemeral: true };
            if (interaction.deferred || interaction.replied) {
                await interaction.followUp(replyOptions).catch(()=>{});
            } else {
                await interaction.reply(replyOptions).catch(()=>{});
            }
        }
    },
};