const { Events } = require('discord.js');
const mongoose = require('mongoose');
require('dotenv').config();

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        console.log(`Pronto! Logado como ${client.user.tag}`);

        // Conectar ao MongoDB
        try {
            await mongoose.connect(process.env.MONGO_URI);
            console.log('Conectado ao MongoDB.');
        } catch (error) {
            console.error('Erro ao conectar ao MongoDB:', error);
        }
    },
};